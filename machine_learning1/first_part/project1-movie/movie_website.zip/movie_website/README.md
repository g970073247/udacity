This program provide you some infomations of movies;
If you want to run this program,you need to place three
files(movie.py, movie_website.py, fresh_tomatoes.py) in 
the same folder. If you want to open the movie trailer
website, you need to run the file "movie_website.py". 
